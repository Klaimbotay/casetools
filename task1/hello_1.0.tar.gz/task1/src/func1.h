void print_hello();
int factorial(int i);
